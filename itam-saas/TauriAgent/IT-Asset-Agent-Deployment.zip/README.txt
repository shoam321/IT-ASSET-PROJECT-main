﻿IT Asset Monitoring Agent - User Guide
=======================================

QUICK START:
1. Double-click tauriagent.exe
2. Login with your credentials  
3. Minimize to tray - it will keep running

AUTO-START (Optional):
1. Press Win+R, type: shell:startup
2. Create shortcut to tauriagent.exe there

TROUBLESHOOTING:
- Won't start: Run as Administrator
- Can't login: Check internet connection
- Not syncing: Wait 2 minutes, then refresh dashboard

System Requirements: Windows 10/11 64-bit

Support: Contact IT Department
